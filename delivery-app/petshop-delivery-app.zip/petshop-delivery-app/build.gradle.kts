// Top-level build file — plugins are declared here (with apply false) and
// actually applied in app/build.gradle.kts, the standard AGP/Kotlin DSL setup.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "1.9.24" apply false
}
