# Happy Tails Rider

A delivery-partner Android app for the Happy Tails Pet Store project — sign in as a rider, see
your assigned orders, walk each one through picked up → out for delivery → delivered (or report
a failed attempt), and share your live location while a delivery is active. Modeled on the
"delivery guy" experience in apps like Amazon's.

This app is the client half of a pair of changes. The other half — new tables, endpoints, and a
small admin-panel addition — was written into your PHP project (`petshop`) directly; see
`DELIVERY_APP.md` there for what changed and how to run it. **The app has nothing to talk to
until that backend is running and at least one order is assigned to a rider.**

## Quick start

1. In the PHP project: `php database/migrate.php up && php database/seed.php`, then start the
   server (`php -S localhost:8000 -t public public/router.php`). Copy the demo rider's printed
   credentials (`rider@happytails.test` / a generated password — printed once, at seed time).
2. In **Admin → Orders**, open an order and assign it to the demo rider (see the new "Delivery
   partner" card).
3. Open this project in Android Studio (Giraffe/2023.1 or newer; File → Open → select this
   folder), let it sync — first sync needs network access to download Gradle, the Android Gradle
   Plugin, and dependencies from Google's and Maven Central's repositories.
4. Run on the emulator (▶ button). The app's default API address, `http://10.0.2.2:8000/...`, is
   the emulator's alias for your machine's `localhost:8000` — no configuration needed if you're
   running the PHP dev server locally.
5. Sign in with the rider credentials from step 1. The assigned order should appear immediately.

## Pointing it at a real device or server

`10.0.2.2` only works from the Android *emulator*. For a physical phone on the same Wi-Fi as your
dev machine, replace it with your machine's LAN IP (e.g. `http://192.168.1.42:8000/api/v1/delivery/`)
in `API_BASE_URL` in `app/build.gradle.kts`, and add that IP to
`app/src/main/res/xml/network_security_config.xml` (cleartext HTTP is only allowed for the hosts
listed there). Once the PHP project is deployed somewhere with HTTPS (see its `DEPLOY.md`), point
`API_BASE_URL` at that URL instead and you can remove the network security config file entirely —
HTTPS doesn't need the cleartext exception.

## What's in here

- **Kotlin + Jetpack Compose**, Material 3, using the storefront's own brand palette (see
  `ui/theme/Theme.kt`) so the app doesn't look like a bolted-on tool.
- **Retrofit + kotlinx.serialization** for the API client (`data/remote/`), wrapped by
  `DeliveryRepository` (`data/repo/`) so screens never touch HTTP directly.
- **EncryptedSharedPreferences** (`data/local/TokenStore.kt`) for the rider's bearer token — same
  sensitivity as a password, so it's not in plain prefs.
- **A foreground `Service`** (`location/LocationTrackingService.kt`) that pings the rider's
  location every 25s to the API while a delivery is "out for delivery" — started/stopped
  automatically from the order detail screen, with a persistent notification (required by Android
  for background location access).
- Three screens (`ui/login`, `ui/orders`, `ui/orderdetail`), wired together with
  `androidx.navigation.compose` (`ui/nav/NavGraph.kt`). No ViewModel/DI framework — state lives
  directly in the composables via `remember`/`rememberCoroutineScope`, which is plenty for an app
  this size and keeps the file count down.
- "Navigate" opens Google Maps turn-by-turn to the customer's address (falls back to any maps app
  via a generic `geo:` intent if Maps isn't installed); "Call" opens the dialer.

## Permissions

Requested on first launch: precise/approximate location (for the delivery-tracking ping) and, on
Android 13+, notifications (for the "delivery in progress" foreground-service notification). If
denied, the app still works for viewing orders and updating status — only the location ping stops
functioning, which the delivery still completes without.

## Known gaps (natural next steps, not built here)

- No push notifications for new assignments — the orders list polls every 20s instead, which
  needed no new backend dependency (see the PHP project's `DELIVERY_APP.md` for why).
- No proof-of-delivery photo/signature capture.
- No customer-facing "track my delivery" map — the backend's public tracking endpoint
  (`GET /api/v1/delivery/track/{orderNumber}`) is ready for it, just not wired into the storefront.
- The launcher icon is a simple placeholder vector (a paw print) — swap
  `app/src/main/res/drawable/ic_launcher_foreground.xml` for real artwork whenever you like.
