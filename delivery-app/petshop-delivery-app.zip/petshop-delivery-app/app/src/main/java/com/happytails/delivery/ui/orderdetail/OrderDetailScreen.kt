package com.happytails.delivery.ui.orderdetail

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.happytails.delivery.data.model.Assignment
import com.happytails.delivery.data.model.ShippingAddress
import com.happytails.delivery.data.repo.ApiResult
import com.happytails.delivery.data.repo.DeliveryRepository
import com.happytails.delivery.location.LocationTrackingService
import com.happytails.delivery.util.formatMoney
import com.happytails.delivery.util.statusLabel
import kotlinx.coroutines.launch

@Composable
fun OrderDetailScreen(
    repository: DeliveryRepository,
    orderId: Int,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var assignment by remember { mutableStateOf<Assignment?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isUpdating by remember { mutableStateOf(false) }

    suspend fun load() {
        when (val result = repository.orderDetail(orderId)) {
            is ApiResult.Success -> {
                assignment = result.data
                errorMessage = null
            }
            is ApiResult.Failure -> errorMessage = result.message
        }
        isLoading = false
    }

    LaunchedEffect(orderId) { load() }

    fun applyStatus(newStatus: String) {
        isUpdating = true
        scope.launch {
            when (val result = repository.updateStatus(orderId, newStatus)) {
                is ApiResult.Success -> {
                    assignment = result.data
                    when (newStatus) {
                        Assignment.OUT_FOR_DELIVERY -> LocationTrackingService.start(context, orderId)
                        Assignment.DELIVERED, Assignment.FAILED -> LocationTrackingService.stop(context)
                    }
                }
                is ApiResult.Failure -> errorMessage = result.message
            }
            isUpdating = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(assignment?.orderNumber ?: "Order") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        when {
            isLoading -> Box(modifier = Modifier.padding(padding).fillMaxSize()) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
            assignment == null -> Text(
                errorMessage ?: "Order not found.",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(padding).padding(24.dp),
            )
            else -> OrderDetailContent(
                assignment = assignment!!,
                isUpdating = isUpdating,
                errorMessage = errorMessage,
                modifier = Modifier.padding(padding),
                onCall = { phone -> context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) },
                onNavigate = { address -> openNavigation(context, address) },
                onAdvance = ::applyStatus,
            )
        }
    }
}

@Composable
private fun OrderDetailContent(
    assignment: Assignment,
    isUpdating: Boolean,
    errorMessage: String?,
    modifier: Modifier = Modifier,
    onCall: (String) -> Unit,
    onNavigate: (ShippingAddress) -> Unit,
    onAdvance: (String) -> Unit,
) {
    val address = assignment.shippingAddress

    LazyColumn(modifier = modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text(statusLabel(assignment.status), style = MaterialTheme.typography.titleLarge)
            Text(
                formatMoney(assignment.totalPaise, assignment.currency) + " · " + (assignment.paymentMethod?.uppercase().orEmpty()),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
            )

            if (address != null) {
                Text("Deliver to", style = MaterialTheme.typography.labelLarge)
                Text(address.name.orEmpty(), style = MaterialTheme.typography.bodyLarge)
                Text(
                    listOfNotNull(address.line1, address.line2).joinToString(", "),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    listOfNotNull(address.city, address.state, address.postalCode).joinToString(", "),
                    style = MaterialTheme.typography.bodyMedium,
                )

                Row(modifier = Modifier.padding(top = 12.dp)) {
                    OutlinedButton(onClick = { onNavigate(address) }, modifier = Modifier.padding(end = 8.dp)) {
                        Icon(Icons.Filled.Navigation, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                        Text("Navigate")
                    }
                    if (!address.phone.isNullOrBlank()) {
                        OutlinedButton(onClick = { onCall(address.phone) }) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                            Text("Call")
                        }
                    }
                }
            }

            if (!assignment.customerNotes.isNullOrBlank()) {
                Text(
                    "Note from customer: ${assignment.customerNotes}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 12.dp),
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))
            Text("Items", style = MaterialTheme.typography.labelLarge)
        }

        items(assignment.items.orEmpty()) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("${item.productName} × ${item.quantity}", style = MaterialTheme.typography.bodyMedium)
                Text(formatMoney(item.lineTotalPaise, assignment.currency), style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            if (errorMessage != null) {
                Text(errorMessage, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 12.dp))
            }

            val nextAction = nextActionFor(assignment.status)
            if (nextAction != null) {
                Button(
                    onClick = { onAdvance(nextAction.first) },
                    enabled = !isUpdating,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(nextAction.second)
                }
            }

            if (assignment.status == Assignment.PICKED_UP || assignment.status == Assignment.OUT_FOR_DELIVERY) {
                OutlinedButton(
                    onClick = { onAdvance(Assignment.FAILED) },
                    enabled = !isUpdating,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                ) {
                    Text("Report failed delivery")
                }
            }

            if (assignment.status == Assignment.DELIVERED) {
                Text("Delivered — nice work!", style = MaterialTheme.typography.bodyLarge)
            }
            if (assignment.status == Assignment.FAILED) {
                Text("Marked as failed. Contact your store manager.", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

private fun nextActionFor(status: String): Pair<String, String>? = when (status) {
    Assignment.ASSIGNED -> Assignment.PICKED_UP to "Mark picked up"
    Assignment.PICKED_UP -> Assignment.OUT_FOR_DELIVERY to "Start delivery"
    Assignment.OUT_FOR_DELIVERY -> Assignment.DELIVERED to "Mark delivered"
    else -> null
}

private fun openNavigation(context: android.content.Context, address: ShippingAddress) {
    val query = listOfNotNull(address.line1, address.line2, address.city, address.state, address.postalCode)
        .joinToString(", ")
    val gmmUri = Uri.parse("google.navigation:q=" + Uri.encode(query))
    val mapIntent = Intent(Intent.ACTION_VIEW, gmmUri).apply { setPackage("com.google.android.apps.maps") }

    if (mapIntent.resolveActivity(context.packageManager) != null) {
        context.startActivity(mapIntent)
    } else {
        val genericUri = Uri.parse("geo:0,0?q=" + Uri.encode(query))
        context.startActivity(Intent(Intent.ACTION_VIEW, genericUri))
    }
}
