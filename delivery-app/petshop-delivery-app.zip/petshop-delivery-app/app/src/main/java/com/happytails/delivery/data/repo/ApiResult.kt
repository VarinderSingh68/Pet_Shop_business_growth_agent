package com.happytails.delivery.data.repo

/** A simple success/failure wrapper so screens don't deal with exceptions or HTTP codes directly. */
sealed interface ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>
    data class Failure(val message: String) : ApiResult<Nothing>
}
