package com.happytails.delivery.data.remote

import com.happytails.delivery.data.model.ApiStatus
import com.happytails.delivery.data.model.AssignmentResponse
import com.happytails.delivery.data.model.LocationPingRequest
import com.happytails.delivery.data.model.LoginRequest
import com.happytails.delivery.data.model.LoginResponse
import com.happytails.delivery.data.model.OrdersResponse
import com.happytails.delivery.data.model.StatusUpdateRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * All paths are relative to BuildConfig.API_BASE_URL, which already points
 * at .../api/v1/delivery/ — see app/build.gradle.kts.
 */
interface DeliveryApi {

    @POST("login")
    suspend fun login(@Body body: LoginRequest): Response<LoginResponse>

    @GET("orders")
    suspend fun orders(@Query("status") status: String? = null): Response<OrdersResponse>

    @GET("orders/{id}")
    suspend fun orderDetail(@Path("id") id: Int): Response<AssignmentResponse>

    @POST("orders/{id}/status")
    suspend fun updateStatus(@Path("id") id: Int, @Body body: StatusUpdateRequest): Response<AssignmentResponse>

    @POST("location")
    suspend fun pingLocation(@Body body: LocationPingRequest): Response<ApiStatus>
}
