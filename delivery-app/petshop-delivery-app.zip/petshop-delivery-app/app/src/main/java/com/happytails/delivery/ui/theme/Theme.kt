package com.happytails.delivery.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// The storefront/admin panel's brand palette (see the PHP project's
// DESIGN.md) — reused here so the rider app reads as the same product.
val Ink = Color(0xFF12141C)
val Paper = Color(0xFFF6F7F2)
val Leash = Color(0xFFE8492A)
val Tennis = Color(0xFFF2B705)
val Fern = Color(0xFF1F5F4A)
val Mist = Color(0xFFDDE3DE)

private val LightColors = lightColorScheme(
    primary = Leash,
    onPrimary = Paper,
    secondary = Fern,
    onSecondary = Paper,
    tertiary = Tennis,
    background = Paper,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Mist,
    error = Leash,
)

private val DarkColors = darkColorScheme(
    primary = Leash,
    onPrimary = Ink,
    secondary = Fern,
    background = Ink,
    onBackground = Paper,
    surface = Color(0xFF1C1F2A),
    onSurface = Paper,
    error = Leash,
)

@Composable
fun HappyTailsRiderTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = MaterialTheme.typography, content = content)
}
