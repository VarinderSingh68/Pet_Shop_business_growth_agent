package com.happytails.delivery.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.happytails.delivery.data.repo.DeliveryRepository
import com.happytails.delivery.ui.login.LoginScreen
import com.happytails.delivery.ui.orderdetail.OrderDetailScreen
import com.happytails.delivery.ui.orders.OrdersListScreen

private const val ROUTE_LOGIN = "login"
private const val ROUTE_ORDERS = "orders"
private const val ROUTE_ORDER_DETAIL = "order/{orderId}"

@Composable
fun DeliveryNavGraph(repository: DeliveryRepository) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = if (repository.isLoggedIn) ROUTE_ORDERS else ROUTE_LOGIN,
    ) {
        composable(ROUTE_LOGIN) {
            LoginScreen(
                repository = repository,
                onLoggedIn = {
                    navController.navigate(ROUTE_ORDERS) {
                        popUpTo(ROUTE_LOGIN) { inclusive = true }
                    }
                },
            )
        }

        composable(ROUTE_ORDERS) {
            OrdersListScreen(
                repository = repository,
                onOpenOrder = { orderId -> navController.navigate("order/$orderId") },
                onLogout = {
                    repository.logout()
                    navController.navigate(ROUTE_LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                },
            )
        }

        composable(
            route = ROUTE_ORDER_DETAIL,
            arguments = listOf(navArgument("orderId") { type = NavType.IntType }),
        ) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getInt("orderId") ?: return@composable
            OrderDetailScreen(
                repository = repository,
                orderId = orderId,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
