package com.happytails.delivery.ui.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.happytails.delivery.data.model.Assignment
import com.happytails.delivery.data.repo.ApiResult
import com.happytails.delivery.data.repo.DeliveryRepository
import com.happytails.delivery.util.formatMoney
import com.happytails.delivery.util.statusLabel
import kotlinx.coroutines.delay

private const val POLL_INTERVAL_MS = 20_000L

@Composable
fun OrdersListScreen(
    repository: DeliveryRepository,
    onOpenOrder: (Int) -> Unit,
    onLogout: () -> Unit,
) {
    var assignments by remember { mutableStateOf<List<Assignment>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            when (val result = repository.assignedOrders()) {
                is ApiResult.Success -> {
                    assignments = result.data
                    errorMessage = null
                }
                is ApiResult.Failure -> errorMessage = result.message
            }
            isLoading = false
            delay(POLL_INTERVAL_MS)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My deliveries") },
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Sign out")
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
        ) {
            when {
                isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                assignments.isEmpty() && errorMessage != null -> Text(
                    errorMessage.orEmpty(),
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                )
                assignments.isEmpty() -> Text(
                    "No deliveries assigned right now.",
                    modifier = Modifier.align(Alignment.Center),
                )
                else -> LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    items(assignments, key = { it.assignmentId }) { assignment ->
                        OrderCard(assignment, onClick = { onOpenOrder(assignment.orderId) })
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderCard(assignment: Assignment, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                assignment.orderNumber ?: "Order #${assignment.orderId}",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                statusLabel(assignment.status),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }

        val address = assignment.shippingAddress
        if (address != null) {
            Text(
                listOfNotNull(address.city, address.state).joinToString(", "),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp),
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                formatMoney(assignment.totalPaise, assignment.currency),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                assignment.paymentMethod?.uppercase().orEmpty(),
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}
