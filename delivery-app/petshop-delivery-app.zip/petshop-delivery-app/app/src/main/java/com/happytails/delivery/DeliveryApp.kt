package com.happytails.delivery

import android.app.Application
import com.happytails.delivery.data.local.TokenStore
import com.happytails.delivery.data.remote.ApiClient
import com.happytails.delivery.data.repo.DeliveryRepository

/**
 * Wires up the (small) dependency graph by hand — a DI framework like Hilt
 * would be overkill for three classes. [repository] is read from here by
 * MainActivity and LocationTrackingService alike.
 */
class DeliveryApp : Application() {

    lateinit var tokenStore: TokenStore
        private set

    lateinit var repository: DeliveryRepository
        private set

    override fun onCreate() {
        super.onCreate()
        tokenStore = TokenStore(this)
        repository = DeliveryRepository(ApiClient.create(tokenStore), tokenStore)
    }
}
