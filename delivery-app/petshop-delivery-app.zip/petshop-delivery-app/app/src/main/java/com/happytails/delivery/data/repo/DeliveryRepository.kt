package com.happytails.delivery.data.repo

import android.os.Build
import com.happytails.delivery.data.local.TokenStore
import com.happytails.delivery.data.model.ApiMessage
import com.happytails.delivery.data.model.Assignment
import com.happytails.delivery.data.model.LocationPingRequest
import com.happytails.delivery.data.model.LoginRequest
import com.happytails.delivery.data.model.Partner
import com.happytails.delivery.data.model.StatusUpdateRequest
import com.happytails.delivery.data.remote.DeliveryApi
import kotlinx.serialization.json.Json
import retrofit2.Response
import java.io.IOException

/**
 * Everything a screen needs, in plain suspend functions returning
 * ApiResult — the HTTP/JSON plumbing (auth header, error-body parsing)
 * lives here so the UI layer never touches Retrofit directly.
 */
class DeliveryRepository(
    private val api: DeliveryApi,
    private val tokenStore: TokenStore,
) {
    val isLoggedIn: Boolean get() = tokenStore.token != null
    val partnerName: String? get() = tokenStore.partnerName

    suspend fun login(email: String, password: String): ApiResult<Partner> {
        val result = safeCall { api.login(LoginRequest(email, password, Build.MODEL)) }
        return when (result) {
            is ApiResult.Success -> {
                val token = result.data.token
                val partner = result.data.partner
                if (token != null && partner != null) {
                    tokenStore.token = token
                    tokenStore.partnerName = partner.name
                    ApiResult.Success(partner)
                } else {
                    ApiResult.Failure(result.data.message ?: "Login failed.")
                }
            }
            is ApiResult.Failure -> result
        }
    }

    fun logout() {
        tokenStore.clear()
    }

    suspend fun assignedOrders(status: String? = null): ApiResult<List<Assignment>> {
        return when (val result = safeCall { api.orders(status) }) {
            is ApiResult.Success -> ApiResult.Success(result.data.data)
            is ApiResult.Failure -> result
        }
    }

    suspend fun orderDetail(id: Int): ApiResult<Assignment> {
        return when (val result = safeCall { api.orderDetail(id) }) {
            is ApiResult.Success -> ApiResult.Success(result.data.data)
            is ApiResult.Failure -> result
        }
    }

    suspend fun updateStatus(
        id: Int,
        status: String,
        note: String? = null,
        lat: Double? = null,
        lng: Double? = null,
    ): ApiResult<Assignment> {
        val body = StatusUpdateRequest(status, note, lat, lng)
        return when (val result = safeCall { api.updateStatus(id, body) }) {
            is ApiResult.Success -> ApiResult.Success(result.data.data)
            is ApiResult.Failure -> result
        }
    }

    suspend fun pingLocation(lat: Double, lng: Double, orderId: Int?): ApiResult<Unit> {
        return when (val result = safeCall { api.pingLocation(LocationPingRequest(lat, lng, orderId)) }) {
            is ApiResult.Success -> ApiResult.Success(Unit)
            is ApiResult.Failure -> result
        }
    }

    private suspend fun <T> safeCall(block: suspend () -> Response<T>): ApiResult<T> {
        return try {
            val response = block()
            val body = response.body()
            if (response.isSuccessful && body != null) {
                ApiResult.Success(body)
            } else {
                ApiResult.Failure(errorMessage(response))
            }
        } catch (e: IOException) {
            ApiResult.Failure("Can't reach the server — check your connection and the API address in Settings.")
        } catch (e: Exception) {
            ApiResult.Failure(e.message ?: "Something went wrong.")
        }
    }

    private fun errorMessage(response: Response<*>): String {
        val raw = response.errorBody()?.string()
        val parsed = raw?.let {
            try {
                Json { ignoreUnknownKeys = true }.decodeFromString(ApiMessage.serializer(), it).message
            } catch (e: Exception) {
                null
            }
        }
        return parsed ?: "Request failed (${response.code()})."
    }
}
