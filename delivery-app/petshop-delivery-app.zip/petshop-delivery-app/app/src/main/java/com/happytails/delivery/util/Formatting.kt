package com.happytails.delivery.util

import java.util.Locale

/** orders/payments store money as integer paise — see the PHP project's SCHEMA.md. */
fun formatMoney(paise: Int?, currency: String? = "INR"): String {
    if (paise == null) return "—"
    val symbol = if (currency == "INR" || currency == null) "₹" else "$currency "
    return String.format(Locale.US, "%s%,.2f", symbol, paise / 100.0)
}

fun statusLabel(status: String?): String {
    return status?.replace('_', ' ')?.replaceFirstChar { it.uppercase() } ?: "—"
}
