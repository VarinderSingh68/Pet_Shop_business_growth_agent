package com.happytails.delivery.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Wire types for /api/v1/delivery/* — field names/shapes mirror
 * DeliveryController::formatAssignment() in the PHP project exactly (see
 * API.md there). Kotlin property names are idiomatic camelCase; @SerialName
 * maps them back to the API's snake_case.
 */

@Serializable
data class LoginRequest(
    val email: String,
    val password: String,
    @SerialName("device_name") val deviceName: String? = null,
)

@Serializable
data class Partner(
    val id: Int,
    val name: String,
    val email: String,
)

@Serializable
data class LoginResponse(
    val token: String? = null,
    val partner: Partner? = null,
    val message: String? = null,
)

@Serializable
data class ShippingAddress(
    val name: String? = null,
    val phone: String? = null,
    val line1: String? = null,
    val line2: String? = null,
    val city: String? = null,
    val state: String? = null,
    @SerialName("postal_code") val postalCode: String? = null,
    val country: String? = null,
)

@Serializable
data class OrderItem(
    @SerialName("product_name") val productName: String,
    @SerialName("variant_label") val variantLabel: String? = null,
    val quantity: Int,
    @SerialName("line_total_paise") val lineTotalPaise: Int,
)

/** One delivery assignment, optionally joined with the order it's for. */
@Serializable
data class Assignment(
    @SerialName("assignment_id") val assignmentId: Int,
    @SerialName("order_id") val orderId: Int,
    @SerialName("order_number") val orderNumber: String? = null,
    val status: String,
    @SerialName("order_status") val orderStatus: String? = null,
    @SerialName("assigned_at") val assignedAt: String? = null,
    @SerialName("picked_up_at") val pickedUpAt: String? = null,
    @SerialName("out_for_delivery_at") val outForDeliveryAt: String? = null,
    @SerialName("delivered_at") val deliveredAt: String? = null,
    val notes: String? = null,
    @SerialName("total_paise") val totalPaise: Int? = null,
    val currency: String? = null,
    @SerialName("payment_method") val paymentMethod: String? = null,
    @SerialName("payment_status") val paymentStatus: String? = null,
    @SerialName("customer_notes") val customerNotes: String? = null,
    @SerialName("shipping_address") val shippingAddress: ShippingAddress? = null,
    val items: List<OrderItem>? = null,
) {
    companion object {
        const val ASSIGNED = "assigned"
        const val PICKED_UP = "picked_up"
        const val OUT_FOR_DELIVERY = "out_for_delivery"
        const val DELIVERED = "delivered"
        const val FAILED = "failed"
    }
}

@Serializable
data class OrdersResponse(val data: List<Assignment> = emptyList())

@Serializable
data class AssignmentResponse(val data: Assignment)

@Serializable
data class ApiMessage(val message: String? = null)

@Serializable
data class StatusUpdateRequest(
    val status: String,
    val note: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
)

@Serializable
data class LocationPingRequest(
    val lat: Double,
    val lng: Double,
    @SerialName("order_id") val orderId: Int? = null,
)

@Serializable
data class ApiStatus(val status: String? = null)
