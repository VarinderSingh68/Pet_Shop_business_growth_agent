# Add project specific ProGuard rules here.
# Release build has minification disabled (see app/build.gradle.kts), so this
# file is a placeholder for when that's turned on later.
